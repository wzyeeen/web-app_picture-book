# 設定api的地方，用到flask_smorest的blueprint
from flask import request
from flask.views import MethodView
from flask_smorest import Blueprint, abort
from sqlalchemy.exc import SQLAlchemyError, IntegrityError

from db import db
from models import UserModel
from schemas import UserSchema

blp = Blueprint("users", __name__, description= "Operations on users")

@blp.route("/user/<string:user_id>")
class User(MethodView):
    @blp.response(200, UserSchema)
    def get(self, user_id):
        user= UserModel.query.get_or_404(user_id)
        return user
        

    def delete(self, user_id):
        user = UserModel.query.get_or_404(user_id)
        if user.logIn == 1:
            db.session.delete(user)
            db.session.commit()
            return {"message": "User deleted"}
        else:
            return {"message": "User delete fail. Not login"}

@blp.route("/user")
class Userlist(MethodView):
            
    @blp.response(200, UserSchema(many=True)) 
    def get(self):
        return UserModel.query.all()
    
    @blp.arguments(UserSchema)
    @blp.response(201, UserSchema)

    def post(self, user_data):  
        user= UserModel( **user_data, logIn = 0)
        try:
            db.session.add(user)
            db.session.commit()
        except IntegrityError:
            abort(400, message = "A user with that name already exists.")

        except SQLAlchemyError:
            abort(500, message = "An error occurred while cteating the user.")

        return user
    

@blp.route("/login/<string:user_name>/<string:user_pwd>")
class Userlist(MethodView):
    # @blp.response(200, UserSchema(many=True))
    def post(self, user_name, user_pwd):
        user = UserModel.query.filter(UserModel.name == user_name).first()
        if user:
            if user.pwd == user_pwd :
                user= UserModel.query.get(user.id)
                user.logIn = 1
                db.session.add(user)
                db.session.commit()
                return {"logState": True}
            else:
                return{"logState": False}
        else:
            return{"logState": False}

# @blp.route("/login/<string:user_name>/<string:user_pwd>")
# class Storelist(MethodView):
#     # @blp.response(200, UserSchema(many=True))
#     def post(self, user_name, user_pwd):
#         user = UserModel.query.filter(UserModel.name == user_name).first()
#         if user.pwd == user_pwd :
#             user= UserModel.query.get(user.id)
#             user.logIn = 1
#             db.session.add(user)
#             db.session.commit()
#             return {"logState": True}
#         else:
#             return{"logState": False}
        