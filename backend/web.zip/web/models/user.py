#在db.py宣告完SQLalchemy的db後，在models的資料夾內設定資料表的內容
from db import db


class UserModel(db.Model):
    __tablename__ = "users"

    id  = db.Column(db.Integer, primary_key = True)
    name  = db.Column(db.String(80), unique = True, nullable = False)
    pwd  = db.Column(db.String(80), nullable = False)
    logIn = db.Column(db.Integer, nullable = False)
    items = db.relationship("ItemModel", back_populates = "user", lazy ="dynamic", cascade = "all, delete-orphan")
    