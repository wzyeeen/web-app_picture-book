# schema，可以讓輸入進的資料跟輸出進的資料格式轉成我們想要的
from marshmallow import Schema, fields

class PlainItemSchema(Schema):
    id = fields.Str(dump_only=True)
    name = fields.Str(required = True)
    price= fields.Float(required = True)
    # store_id = fields.Str(required = True) 

class PlainUserSchema(Schema):
    id = fields.Str(dump_only=True)
    name = fields.Str(required = True)
    pwd = fields.Str(required = True)
    logIn = fields.Int(dump_only=True)

class ItemUpdateSchema(Schema):
    name = fields.Str()
    price= fields.Float()
    store_id = fields.Int()

class ItemSchema(PlainItemSchema):
    store_id = fields.Int(required = True, load_omly = True)
    store = fields.Nested(PlainUserSchema(), dump_omly=True)

class UserSchema(PlainUserSchema):
    items = fields.List(fields.Nested(PlainItemSchema()), dump_only = True)